کاربر گرامی،
نام کاربری شما در سایت شورای صنفی دانشکده کامپیوتر: <?php echo e($student_number); ?> می‌باشد.
شما می‌توانید با استفاده از لینک زیر، رمز عبور خود را برای ورود به سایت بازنشانی کنید:
<?php echo e($url); ?>


اگر تقاضای بازنشانی رمز عبور خود را نداشتید، این پیام را نادیده بگیرید
<?php /**PATH /media/taha/D60061E80061CFD37/Term 5/Shora/website/shora-backend/resources/views/mail.blade.php ENDPATH**/ ?>