import { atom } from 'recoil';

export const transactionsAtom = atom({
    key: 'transactionsAtom',
    default: null,
});