import { atom } from 'recoil';

export const lockersAtom = atom({
    key: 'lockersAtom',
    default: null,
});