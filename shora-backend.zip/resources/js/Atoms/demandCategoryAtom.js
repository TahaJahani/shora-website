import { atom } from 'recoil';

export const demandCategoryAtom = atom({
    key: 'demandCategoryAtom',
    default: [],
});