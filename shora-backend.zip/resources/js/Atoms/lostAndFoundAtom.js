import { atom } from 'recoil';

export const lostAndFoundAtom = atom({
    key: 'lostAndFoundAtom',
    default: null,
});