import { atom } from 'recoil';

export const demandsAtom = atom({
    key: 'demandsAtom',
    default: null,
});