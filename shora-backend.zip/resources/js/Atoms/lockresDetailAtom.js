import { atom } from 'recoil';

export const lockersDetailAtom = atom({
    key: 'lockersDetailAtom',
    default: null,
});