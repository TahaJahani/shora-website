import { atom } from 'recoil';

export const eventsAtom = atom({
    key: 'eventsAtom',
    default: null,
});