import { atom } from 'recoil';

export const notificationsAtom = atom({
    key: 'notificationsAtom',
    default: 0,
});