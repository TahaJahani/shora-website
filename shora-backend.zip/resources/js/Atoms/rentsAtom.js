import { atom } from 'recoil';

export const rentsAtom = atom({
    key: 'rentsAtom',
    default: null,
});