const colors = {
    success: {
        light: "#4caf50"
    },
    error: {
        light: "#ef5350"
    },
    blue: {
        light: "#fbfdfe",
        middle: "#f8fcfd"
    }
}

export default colors;